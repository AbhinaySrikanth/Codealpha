package com.example.stoicquotesgenerator

data class QuoteData(
    val author: String,
    val quote: String
)