package com.example.androidproject

object User {

    var user_token: String = ""

}